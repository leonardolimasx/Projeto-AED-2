#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <locale.h>

#include "pilha.h"

main()
{

    setlocale(LC_ALL, "Portuguese");

    char frase[256] = {""};
    char dicionario[10][20] = {"FEIO", "FRACASSADO", "IDIOTA", "INUTIL", "ESQUISITO", "CHATO","ESTRANHO","BURRO", "GORDO", "MAGRELO" }; 
    char *token;
    int i, j;

    pilha p;
    cria(&p);

    printf("digite uma frase =");
    gets(frase);
    printf("\nFrase digitada = %s\n\n", frase);

    for (i = 0; i < strlen(frase); i++)
    {
        frase[i] = toupper(frase[i]);
    }

    printf("Frase convertida para maiusculas= %s\n", frase);

    for (i = 0; i < strlen(frase); i++)
    {
        if (frase[i] == '.' || frase[i] == ',' || frase[i] == ':' || frase[i] == ';' || frase[i] == '?' || frase[i] == '!')
            frase[i] = ' ';
    }

    token = strtok(frase, " ");

    while (token)
    {

        for (i = 0; i < 10; i++)
        {
            if (strcmp(token, dicionario[i]) == 0)
            {
                printf("\nA palavra censurada \32 %s\n\n", token);
                for (j = 0; j < strlen(token); j++)
                    token[j] = '-';
            }
        }
        empilha(&p, token);
        token = strtok(NULL, " ");
    }

    
    mostra(p);
    
}