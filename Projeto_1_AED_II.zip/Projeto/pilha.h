struct no
{
    char string[256]; 
    struct no *prox; 
};

typedef struct
{
    struct no *topo;
    
} pilha;

void cria(pilha *s);
char empilha(pilha *s, char frase[]);
char estaVazia(pilha s);
void mostra(pilha s);

void cria(pilha *s)
{
    s->topo = NULL;
}

char empilha(pilha *s, char frase[])
{
    struct no *aux;
    int i, j;
    aux = (struct no *)malloc(sizeof(struct no));
    
    if (aux == NULL)
        return 0;
    strcpy(aux->string, frase); 
    aux->prox = s->topo;
    s->topo = aux;
    return 1;
}

void mostra(pilha s)
{
    struct no *aux;
    aux = s.topo;
    int i;

    if(!estaVazia(s))
    {
        while (aux != NULL)
        {
            for(i = 0; i < aux->string; i++){
            printf("Palavra %d: %s\n", i, aux->string);
            aux = aux->prox;
            }
        }
    }
}

char estaVazia(pilha s)
{
    if (s.topo == NULL)
        return 1;
    return 0;
}

