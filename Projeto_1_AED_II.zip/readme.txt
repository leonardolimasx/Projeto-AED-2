Descrição do Projeto 1 de AED II :

O projeto foi feito pensando em censurar palavras que normalmente são usadas para fazer bullying com as pessoas, para isso
usamos a estrutura de dados dinâmicas do tipo pilha e criamos um banco de dados com 10 palavras usadas para agressão verbal.

Integrantes do Grupo:
- Rafael Leite da Silva Cireli
- Daniel Boccalini Pontes
- Matheus Evangelista de Brito